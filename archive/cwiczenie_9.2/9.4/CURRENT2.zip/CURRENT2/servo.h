void ServoGoTo(unsigned int uiPosition);
void ServoCallib(void);
void ServoInit(unsigned int uiServoFrequency);
void ServoShiftTo(unsigned int uiShiftStep);

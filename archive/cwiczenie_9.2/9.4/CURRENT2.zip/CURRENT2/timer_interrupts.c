#include <LPC21xx.H>
#include "timer_interrupts.h"

// TIMER
#define mCOUNTER_ENABLE_bm (1<<0)
#define mCOUNTER_RESET_bm  (1<<1)

// CompareMatch
#define mINTERRUPT_ON_MR0_bm (1<<0)
#define mRESET_ON_MR0_bm     (1<<1)
#define mMR0_INTERRUPT_bm   (1<<0)

// VIC (Vector Interrupt Controller) VICIntEnable
#define VIC_TIMER0_CHANNEL_NR 4

// VICVectCntlx Vector Control Registers
#define mIRQ_SLOT_ENABLE_bm (1<<5)

//wskaznik na funkcje
void (*ptrTimer0InterruptFunction)(void);
void (*ptrTimer1InterruptFunction)(void);
/**********************************************/
//(Interrupt Service Routine) of Timer 0 interrupt
__irq void Timer0IRQHandler(){

	T0IR= mMR0_INTERRUPT_bm ; 	// skasowanie flagi przerwania 
	ptrTimer0InterruptFunction();		
	VICVectAddr=0x00; 	// potwierdzenie wykonania procedury obslugi przerwania
}

__irq void Timer1IRQHandler(){

	T0IR= mMR0_INTERRUPT_bm ; 	// skasowanie flagi przerwania 
	ptrTimer1InterruptFunction();		
	VICVectAddr=0x00; 	// potwierdzenie wykonania procedury obslugi przerwania
}


/**********************************************/
void Timer0Interrupts_Init(unsigned int uiPeriod,void(*ptrTimer0IntFunction)(void)){ // microseconds
	ptrTimer0InterruptFunction = ptrTimer0IntFunction;
        // interrupts

	VICIntEnable |= (0x1 << VIC_TIMER0_CHANNEL_NR);            // Enable Timer 0 interrupt channel 
	VICVectCntl0  = mIRQ_SLOT_ENABLE_bm | VIC_TIMER0_CHANNEL_NR;  // Enable Slot 0 and assign it to Timer 0 interrupt channel
	VICVectAddr0  =(unsigned long)Timer0IRQHandler; 	   // Set to Slot 0 Address of Interrupt Service Routine 

        // match module

	T0MR0 = 15 * uiPeriod;                 	      // value 
	T0MCR |= (mINTERRUPT_ON_MR0_bm | mRESET_ON_MR0_bm ); // action 

        // timer

	T0TCR =  mCOUNTER_ENABLE_bm; // start 

}

void Timer1Interrupts_Init(unsigned int uiPeriod,void(*ptrTimer1IntFunction)(void)){ // microseconds
	ptrTimer1InterruptFunction = ptrTimer1IntFunction;
        // interrupts

	VICIntEnable |= (0x1 << VIC_TIMER0_CHANNEL_NR);            // Enable Timer 1 interrupt channel 
	VICVectCntl5 = mIRQ_SLOT_ENABLE_bm | VIC_TIMER0_CHANNEL_NR;  // Enable Slot 1 and assign it to Timer 0 interrupt channel
	VICVectAddr5  =(unsigned long)Timer1IRQHandler; 	   // Set to Slot 0 Address of Interrupt Service Routine 

        // match module

	T0MR0 = 15 * uiPeriod;                 	      // value 
	T0MCR |= (mINTERRUPT_ON_MR0_bm | mRESET_ON_MR0_bm ); // action 

        // timer

	T0TCR =  mCOUNTER_ENABLE_bm; // start 

}


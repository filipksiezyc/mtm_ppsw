#include "string.h"

#define NULL 0



enum CompResult eCompareString(char pcStr1[], char pcStr2[]){
	unsigned char ucCharCounter;

	for(ucCharCounter = 0; pcStr1[ucCharCounter] != NULL; ucCharCounter++){
		if( pcStr1[ucCharCounter] != pcStr2[ucCharCounter] ){
			return DIFFERENT;
		}
	}
	if( pcStr1[ucCharCounter] != pcStr2[ucCharCounter] ){
		return DIFFERENT;
	}
	return EQUAL;
}

void CopyString(char pcSource[], char pcDestination[]){
	unsigned char ucCharCounter;
	
	for(ucCharCounter = 0; pcSource[ucCharCounter]; ++ucCharCounter){
		pcDestination[ucCharCounter] = pcSource[ucCharCounter];
	}
	pcDestination[ucCharCounter] = pcSource[ucCharCounter];
}

void ReplaceCharactersInString(char pcString[],char cOldChar,char cNewChar){
	unsigned char ucCharCounter;
		for(ucCharCounter = 0; pcString[ucCharCounter] != NULL; ++ucCharCounter){
			if(pcString[ucCharCounter] == cOldChar){
				pcString[ucCharCounter] = cNewChar;
			}
		}
}


enum Result eHexStringToUInt(char pcStr[],unsigned int *puiValue){
	unsigned char ucCharacterCounter;
	unsigned char ucCurrentCharacter;
	*puiValue=0;

	if((pcStr[0]!='0') || (pcStr[1]!='x') || (pcStr[2]==NULL)){
		return ERROR;
	}
	for(ucCharacterCounter=2; ucCharacterCounter<7; ucCharacterCounter++){
		ucCurrentCharacter = pcStr[ucCharacterCounter];
		
		if(ucCurrentCharacter==NULL){
			return OK;
		}
		else if(ucCharacterCounter==6){
			return ERROR;
		}
	
	*puiValue = *puiValue << 4;
	if(ucCurrentCharacter <= '9' && ucCurrentCharacter >= '0'){
		ucCurrentCharacter = ucCurrentCharacter-'0';
	}
	else if(ucCurrentCharacter <= 'F' && ucCurrentCharacter >= 'A'){
		ucCurrentCharacter = ucCurrentCharacter-'A'+10;
	}
	else{
		return ERROR;
	}
	*puiValue = (*puiValue) | ucCurrentCharacter;
	}
	return ERROR;
}


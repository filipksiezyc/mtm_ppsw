#define RECIEVER_SIZE 11
#define TRANSMITER_SIZE 11

#define TERMINATOR 	'\r'


enum eRecieverStatus {EMPTY, READY, OVERFLOW};

enum eTransmiterStatus {FREE, BUSY};

typedef struct TransmiterBuffer{
	char cData[TRANSMITER_SIZE];
	enum eTransmiterStatus eStatus;
	unsigned char fLastCharacter;
	unsigned char cCharCtr;
}TransmiterBuffer;


struct ReciverBuffer{
	char cData[RECIEVER_SIZE];
	unsigned char ucCharCtr;
	enum eRecieverStatus eStatus;

};	


void UART_InitWithInt(unsigned int uiBaudRate);
void Reciever_PutCharacterToBuffer(char cCharacter);
enum eRecieverStatus eReciever_GetStatus(void);
void Reciever_GetStringCopy(char *ucDestination);
char Transmiter_GetCharacterFromBuffer(void);
enum eTransmiterStatus Transmiter_GetStatus(void);
void Transmiter_SendString(char *ucString);

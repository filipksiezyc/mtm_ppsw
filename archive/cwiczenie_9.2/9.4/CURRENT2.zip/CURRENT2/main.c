#include "uart.h"
#include "command_decoder.h"
#include "servo.h"
#include "string.h"

extern struct ReciverBuffer sRxBuffer;
extern struct Token asToken[MAX_TOKEN_NR];
extern struct TransmiterBuffer sTransmiterBuffer;

extern unsigned char ucTokenNr;
extern char cWysylanie;

int main(){
	
	unsigned int cLoop;
	
	while(1){
		for(cLoop =0; cLoop<256;cLoop++)
			cWysylanie++;
	
	}
	
	
	/*char cTest[RECIEVER_SIZE];

	ServoInit(50);
	UART_InitWithInt(9600);

	sRxBuffer.eStatus=EMPTY;
	sRxBuffer.ucCharCtr=0;
	

	 while(1){
		if(eReciever_GetStatus()== READY){
			Reciever_GetStringCopy(cTest);
			DecodeMsg(cTest);
			
			if((ucTokenNr !=0) &&	(asToken[0].eType==KEYWORD)){
					
					switch(asToken[0].uValue.eKeyword){
					
							case CALLIB:
								ServoCallib();
								break;
							
							case GOTO:
								if(asToken[1].eType==NUMBER){
									ServoGoTo(asToken[1].uValue.uiNumber);
									break;
								}
								else{
								break;
								}
							
							case SHIFT:
								if(asToken[1].eType==NUMBER){
									ServoShiftTo(asToken[1].uValue.uiNumber);
									break;
									}
								else{
									break;
								}
					}
			}		
		}
	} */
}

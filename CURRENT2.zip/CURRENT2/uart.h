void UART_InitWithInt(unsigned int uiBaudRate);

void InitTimer0(void);
void WaitOnTimer0(unsigned int uiTime);
void WaitOnTimer0Match0(void);
void InitTimer0Match0(unsigned int iDelayTime);

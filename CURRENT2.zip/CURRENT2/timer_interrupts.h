void Timer0Interrupts_Init(unsigned int uiPeriod,void(*ptrTimer0IntFunction)(void));
void Timer1Interrupts_Init(unsigned int uiPeriod,void(*ptrTimer1IntFunction)(void));

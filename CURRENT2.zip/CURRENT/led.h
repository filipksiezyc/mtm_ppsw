
void LedInit(void);
void LedStepRight(void);
void LedStepLeft(void);

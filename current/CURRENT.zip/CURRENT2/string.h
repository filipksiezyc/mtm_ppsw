enum CompResult {EQUAL, DIFFERENT};
enum Result {OK, ERROR};

void ReplaceCharactersInString(char pcString[],char cOldChar,char cNewChar);
enum CompResult eCompareString(char pcStr1[], char pcStr2[]);
enum Result eHexStringToUInt(char pcStr[],unsigned int *puiValue);

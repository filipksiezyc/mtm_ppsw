#include "uart.h"
#include "command_decoder.h"
#include "servo.h"


extern struct ReciverBuffer sRxBuffer;
extern struct Token asToken[MAX_TOKEN_NR];

extern unsigned char ucTokenNr;

int main(){
	
	char cTest[RECIEVER_SIZE];

	ServoInit(50);
	UART_InitWithInt(9600);

	sRxBuffer.eStatus=EMPTY;
	
	
	
	while(1){
		if(eReciever_GetStatus()== READY){
			//Reciever_GetStringCopy(cTest);
			DecodeMsg(cTest);
			
			if(ucTokenNr !=0){
				
				if(asToken[0].eType==KEYWORD){
;	
					
					switch(asToken[0].uValue.eKeyword){
					
							case CALLIB:
								ServoCallib();
								break;
							
							case GOTO:
								if(asToken[1].eType==NUMBER){
									ServoGoTo(asToken[1].uValue.uiNumber);
									break;
								}
								else{
								break;
								}
							}
							ucTokenNr=0;
				}
			}	
			
		}
	
	}
}

void LedOn(unsigned char ucLedIndeks);
void LedInit(void);
void LedStepRight(void);
void LedStepLeft(void);

#define MAX_KEYWORD_STRING_LTH 10
#define MAX_TOKEN_NR 2


enum KeywordCode {CALLIB, GOTO};
enum TokenType {KEYWORD, NUMBER, STRING};

union TokenValue{
	enum KeywordCode eKeyword;
	unsigned int uiNumber;
	char* pcString;
};

struct Token{
	enum TokenType eType;
	union TokenValue uValue;
};


	
struct Keyword{
	enum KeywordCode eCode;
	char cString[MAX_KEYWORD_STRING_LTH + 1];
};

void DecodeMsg(char *pcString);
